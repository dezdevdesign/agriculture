<footer class="footer hidden-xs-down">
    <p>© Department Of Agriculture. All rights reserved.</p>
</footer>