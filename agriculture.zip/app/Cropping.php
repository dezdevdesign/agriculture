<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cropping extends Model
{
    protected $guarded = [];
}
