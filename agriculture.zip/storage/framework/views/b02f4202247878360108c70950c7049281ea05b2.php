var polylineCoordinates_<?php echo $id; ?> = [
	<?php $__currentLoopData = $options['coordinates']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coordinate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		new google.maps.LatLng(<?php echo $coordinate['latitude']; ?>, <?php echo $coordinate['longitude']; ?>),
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
];

var polyline_<?php echo $id; ?> = new google.maps.Polyline({
	path: polylineCoordinates_<?php echo $id; ?>,
	geodesic: <?php echo $options['strokeColor'] ? 'true' : 'false'; ?>,
	strokeColor: '<?php echo $options['strokeColor']; ?>',
	strokeOpacity: <?php echo $options['strokeOpacity']; ?>,
	strokeWeight: <?php echo $options['strokeWeight']; ?>,
	editable: <?php echo $options['editable'] ? 'true' : 'false'; ?>

});

polyline_<?php echo $id; ?>.setMap(<?php echo $options['map']; ?>);

shapes.push({
	'polyline_<?php echo $id; ?>': polyline_<?php echo $id; ?>

});